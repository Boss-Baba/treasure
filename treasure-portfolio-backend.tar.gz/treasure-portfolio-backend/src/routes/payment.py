import os
import stripe
from flask import Blueprint, request, jsonify
from src.models.book import Book, Order, db

payment_bp = Blueprint('payment', __name__)

# Set Stripe API key (in production, use environment variables)
stripe.api_key = os.getenv('STRIPE_SECRET_KEY', 'sk_test_...')  # Replace with your test key

@payment_bp.route('/books', methods=['GET'])
def get_books():
    """Get all available books"""
    try:
        books = Book.query.filter_by(is_available=True).all()
        return jsonify({
            'success': True,
            'books': [book.to_dict() for book in books]
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@payment_bp.route('/books/<int:book_id>', methods=['GET'])
def get_book(book_id):
    """Get a specific book by ID"""
    try:
        book = Book.query.get_or_404(book_id)
        if not book.is_available:
            return jsonify({
                'success': False,
                'error': 'Book is not available'
            }), 404
        
        return jsonify({
            'success': True,
            'book': book.to_dict()
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@payment_bp.route('/create-payment-intent', methods=['POST'])
def create_payment_intent():
    """Create a Stripe payment intent for book purchase"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['book_id', 'customer_email']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        book_id = data['book_id']
        customer_email = data['customer_email']
        customer_name = data.get('customer_name', '')
        quantity = data.get('quantity', 1)
        
        # Get book from database
        book = Book.query.get_or_404(book_id)
        if not book.is_available:
            return jsonify({
                'success': False,
                'error': 'Book is not available'
            }), 400
        
        # Calculate total amount in cents (Stripe uses cents)
        total_amount_dollars = book.price * quantity
        total_amount_cents = int(total_amount_dollars * 100)
        
        # Create payment intent with Stripe
        payment_intent = stripe.PaymentIntent.create(
            amount=total_amount_cents,
            currency=book.currency.lower(),
            metadata={
                'book_id': book_id,
                'book_title': book.title,
                'customer_email': customer_email,
                'customer_name': customer_name,
                'quantity': quantity
            },
            receipt_email=customer_email
        )
        
        # Create order record in database
        order = Order(
            stripe_payment_intent_id=payment_intent.id,
            customer_email=customer_email,
            customer_name=customer_name,
            book_id=book_id,
            quantity=quantity,
            total_amount=total_amount_dollars,
            currency=book.currency,
            status='pending'
        )
        
        db.session.add(order)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'client_secret': payment_intent.client_secret,
            'payment_intent_id': payment_intent.id,
            'order_id': order.id,
            'total_amount': total_amount_dollars,
            'book': book.to_dict()
        })
        
    except stripe.error.StripeError as e:
        return jsonify({
            'success': False,
            'error': f'Stripe error: {str(e)}'
        }), 400
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@payment_bp.route('/confirm-payment', methods=['POST'])
def confirm_payment():
    """Confirm payment and update order status"""
    try:
        data = request.get_json()
        payment_intent_id = data.get('payment_intent_id')
        
        if not payment_intent_id:
            return jsonify({
                'success': False,
                'error': 'Missing payment_intent_id'
            }), 400
        
        # Retrieve payment intent from Stripe
        payment_intent = stripe.PaymentIntent.retrieve(payment_intent_id)
        
        # Find order in database
        order = Order.query.filter_by(stripe_payment_intent_id=payment_intent_id).first()
        if not order:
            return jsonify({
                'success': False,
                'error': 'Order not found'
            }), 404
        
        # Update order status based on payment intent status
        if payment_intent.status == 'succeeded':
            order.status = 'completed'
        elif payment_intent.status == 'canceled':
            order.status = 'failed'
        else:
            order.status = payment_intent.status
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'order': order.to_dict(),
            'payment_status': payment_intent.status
        })
        
    except stripe.error.StripeError as e:
        return jsonify({
            'success': False,
            'error': f'Stripe error: {str(e)}'
        }), 400
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@payment_bp.route('/orders', methods=['GET'])
def get_orders():
    """Get all orders (for admin purposes)"""
    try:
        orders = Order.query.order_by(Order.created_at.desc()).all()
        return jsonify({
            'success': True,
            'orders': [order.to_dict() for order in orders]
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@payment_bp.route('/orders/<int:order_id>', methods=['GET'])
def get_order(order_id):
    """Get a specific order by ID"""
    try:
        order = Order.query.get_or_404(order_id)
        return jsonify({
            'success': True,
            'order': order.to_dict()
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@payment_bp.route('/webhook', methods=['POST'])
def stripe_webhook():
    """Handle Stripe webhooks for payment status updates"""
    payload = request.get_data(as_text=True)
    sig_header = request.headers.get('Stripe-Signature')
    
    # In production, set this to your webhook endpoint secret
    endpoint_secret = os.getenv('STRIPE_WEBHOOK_SECRET', '')
    
    try:
        if endpoint_secret:
            event = stripe.Webhook.construct_event(
                payload, sig_header, endpoint_secret
            )
        else:
            # For development/testing without webhook secret
            event = stripe.Event.construct_from(
                request.get_json(), stripe.api_key
            )
    except ValueError:
        return jsonify({'error': 'Invalid payload'}), 400
    except stripe.error.SignatureVerificationError:
        return jsonify({'error': 'Invalid signature'}), 400
    
    # Handle the event
    if event['type'] == 'payment_intent.succeeded':
        payment_intent = event['data']['object']
        
        # Update order status
        order = Order.query.filter_by(
            stripe_payment_intent_id=payment_intent['id']
        ).first()
        
        if order:
            order.status = 'completed'
            db.session.commit()
    
    elif event['type'] == 'payment_intent.payment_failed':
        payment_intent = event['data']['object']
        
        # Update order status
        order = Order.query.filter_by(
            stripe_payment_intent_id=payment_intent['id']
        ).first()
        
        if order:
            order.status = 'failed'
            db.session.commit()
    
    return jsonify({'status': 'success'})

